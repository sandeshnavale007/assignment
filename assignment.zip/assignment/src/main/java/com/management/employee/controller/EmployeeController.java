package com.management.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.management.employee.dto.EmployeeDto;
import com.management.employee.entity.Employee;
import com.management.employee.service.IEmployeeService;

@RestController
@RequestMapping("employee")
public class EmployeeController {
	@Autowired
	private IEmployeeService employeeService;

	@PostMapping("/")
	public String save(@RequestBody EmployeeDto employeedto) {
		employeeService.save(employeedto);
		return "saved";
	}

	@PutMapping("/")
	public String update(@RequestBody EmployeeDto employee) {
		return employeeService.save(employee);
	}

	@GetMapping("/")
	public List<EmployeeDto> findAll() {
		return (List<EmployeeDto>) employeeService.findAll();
	}

	@GetMapping("/{id}")
	public EmployeeDto findById(@PathVariable("id") long id) {
		return employeeService.findEmpById(id);
	}

	@DeleteMapping("/{id}")
	public String delete(@PathVariable("id") long id) {
		return employeeService.delete(id);
	}

	@GetMapping("/high")
	public List<EmployeeDto> findByHighSalary() {
		return employeeService.findByHighSalary();
	}

	@GetMapping("/less")
	public List<EmployeeDto> findByLessSalary() {
		return employeeService.findByLessSalary();
	}
	
	@GetMapping("/search/{enterNumber}/{options}")
	public List<Employee> findBySalary(@PathVariable("enterNumber") String enterNumber,@PathVariable("options") String options) {
		return employeeService.findBySalary(enterNumber,options);
	}
}
