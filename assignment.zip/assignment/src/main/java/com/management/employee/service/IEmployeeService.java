package com.management.employee.service;

import java.util.List;

import com.management.employee.dto.EmployeeDto;
import com.management.employee.entity.Employee;

public interface IEmployeeService {

	public String save(EmployeeDto employeeDto);

	public List<EmployeeDto> findAll();

	public EmployeeDto findEmpById(long id);
	
	public String delete(long id);

	public List<EmployeeDto> findByHighSalary();

	public List<EmployeeDto> findByLessSalary();

	public List<Employee> findBySalary(String enterNumber, String options);

}
