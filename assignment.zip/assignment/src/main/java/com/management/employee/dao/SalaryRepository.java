package com.management.employee.dao;

import org.springframework.data.repository.CrudRepository;

import com.management.employee.entity.Salary;

public interface SalaryRepository extends CrudRepository<Salary, Long> {

	Salary findByEmployeeId(long id);

}
