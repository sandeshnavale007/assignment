package com.management.employee.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.management.employee.dto.EmployeeDto;

@Repository
public class EmployeeRepositoryImpl {
	@Resource
	private NamedParameterJdbcTemplate em;
	
	private static final String SQL = "SELECT max(s.salary) as salary FROM employee as e inner join salary as s on s.employee_id=e.id";
		public List<EmployeeDto>  findByHighSalary(){
			MapSqlParameterSource param = new MapSqlParameterSource();
		return em.query(SQL, param, new RowMapper<EmployeeDto>() {
		    @Override
		    public EmployeeDto mapRow(ResultSet rs, int rowNum) throws SQLException {
		    	EmployeeDto emp = new EmployeeDto();
		        emp.setSalary(rs.getString(1));
		        return emp;
		    }
		});
	}
	
	private static final String SQL1 = "SELECT max(e.salary) as salary FROM employee as e  where salary < (select max(es.salary) from employee as es ) limit 1";
		public List<EmployeeDto>  findByLessSalary(){
			MapSqlParameterSource param = new MapSqlParameterSource();
		return em.query(SQL1, param, new RowMapper<EmployeeDto>() {
		    @Override
		    public EmployeeDto mapRow(ResultSet rs, int rowNum) throws SQLException {
		    	EmployeeDto emp = new EmployeeDto();
		        emp.setSalary(rs.getString(1));
		        return emp;
		    }
		});
	}
}
