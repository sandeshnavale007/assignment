package com.management.employee.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.management.employee.dao.EmployeeRepository;
import com.management.employee.dao.EmployeeRepositoryImpl;
import com.management.employee.dao.SalaryRepository;
import com.management.employee.dto.EmployeeDto;
import com.management.employee.entity.Employee;
import com.management.employee.entity.Salary;

@Service
public class EmployeeService implements IEmployeeService {

	@Autowired
	private EmployeeRepository repository;
	@Autowired
	private SalaryRepository salaryRepository;
	@Autowired
	private EmployeeRepositoryImpl nRepo;

	@Override
	public String save(EmployeeDto employeeDto) {
		Employee employee = new Employee();
		if (employeeDto.getId() == 0) {
			//Add Employee
			BeanUtils.copyProperties(employeeDto, employee);
			repository.save(employee);
			Salary salary = new Salary();
			salary.setEmployeeId(employee.getId());
			salary.setSalary(employeeDto.getSalary());
			salaryRepository.save(salary);
			return "Saves SucessFully";
		} else {
			//update Employee
			BeanUtils.copyProperties(employeeDto, employee);
			repository.save(employee);
			Salary salary = salaryRepository.findByEmployeeId(employeeDto.getId());
			salary.setSalary(employeeDto.getSalary());
			salaryRepository.save(salary);
			return "Update SucessFully";
		}
	}

	@Override
	public List<EmployeeDto> findAll() {
		List<Employee> employee = new ArrayList<Employee>();
		Salary salary = new Salary();
		employee = (List<Employee>) repository.findAll();
		List<EmployeeDto> employeeDto = new ArrayList<EmployeeDto>();
		for (Employee e : employee) {
			EmployeeDto dto = new EmployeeDto();
			salary = salaryRepository.findByEmployeeId(e.getId());
			BeanUtils.copyProperties(e, dto);
			dto.setSalary(salary.getSalary());
			employeeDto.add(dto);
		}
		return employeeDto;
	}

	@Override
	public EmployeeDto findEmpById(long id) {
		Employee employee = repository.findById(id).get();
		EmployeeDto dto = new EmployeeDto();
		Salary salary = salaryRepository.findByEmployeeId(employee.getId());
		BeanUtils.copyProperties(employee, dto);
		dto.setSalary(salary.getSalary());
		return dto;
	}

	@Override
	public String delete(long id) {
		repository.delete(repository.findById(id).get());
		salaryRepository.delete(salaryRepository.findByEmployeeId(id));
		return "Deleted";
	}

	@Override
	public List<EmployeeDto> findByHighSalary() {
		return nRepo.findByHighSalary();
	}

	@Override
	public List<EmployeeDto> findByLessSalary() {
		return nRepo.findByLessSalary();
	}

	@Override
	public List<Employee> findBySalary(String enterNumber, String options) {
		if (options.equalsIgnoreCase("GREATERTHAN")) {
			 List<Employee> employee = repository.findBySalaryGreaterThan(enterNumber);
			 return employee;
		} else if(options.equalsIgnoreCase("LESSTHAN")){
			 List<Employee> employee =  repository.findBySalaryLessThan(enterNumber);
			 return employee;
		}
		return null;
	}

}
