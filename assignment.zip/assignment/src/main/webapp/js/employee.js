var addEmployee = function(e,id){
	e.preventDefault();
	if(!!id){
		url = "http://localhost:8086/employee/";
		type = "PUT";
		var formObject = {id:id};
	}else{
		url = "http://localhost:8086/employee/";
		type = "POST";
		var formObject = {};
	}
	var formData = new FormData(document.getElementById("employeeForm"));
	formData.forEach(function(value,key){
		formObject[key] = value;
	});
	formObject = JSON.stringify(formObject);
	$.ajax({
		  type: type,
		  url: url,
		  data: formObject,
		  success: function(data,status){
			  alert(data,status);
			  $('form#employeeForm')[0].reset();
			 window.location.reload();
			},
		  datatype : "application/json",
		  contentType: "application/json"
	});
}

var getSalary= function(){
	//higest Salary
	var url = "http://localhost:8086/employee/high/";
			$.ajax({
			  type: "GET",
			  url: url,
			  success: function(data){
				  HighSalary=(data);
				console.log(HighSalary);
				$("#highList").loadTemplate("#highSalaryTemplate",HighSalary);
			  },
			  datatype : "application/json",
			  contentType: "application/json"
		});
	//second higest Salary
	var lessUrl = "http://localhost:8086/employee/less/";
		$.ajax({
		  type: "GET",
		  url: lessUrl,
		  data: null,
		  success: function(data){
			  LessSalary=(data);
			  console.log(LessSalary);
			  $("#lowList").loadTemplate("#lowSalaryTemplate",LessSalary);
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
};
getSalary();




$(document).ready(function(){
	registration = $('#employeeTable').DataTable({
		  processing : true,
			destroy: true,
			paging: false,
			searching : false,
			info : false,
		ajax: {
				url: "http://localhost:8086/employee/",
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ {
			data : "fullName",
			'title' : " Name"
		}, {
			data : "email",
			'title' : "Email"
		}, {
			data : "salary",
			'title' : "Salary"
		}, {
			data : "id",
			'title' : "Manage"
		}],
		'columnDefs': [{
			   'targets': 3,
			   'searchable':false,
			   'orderable':false,
			   'className': 'dt-body-center',
			  'render': function (data, type, full, meta){
				   return '<div class="btn-group btn-group-sm"><button type="button" value="' + $('<div/>').text(data).html() + '" onclick="editEmployee(this.value)" class="btn btn-success btn-sm"  title="Edit">Edit</button><button type="button" value="' + $('<div/>').text(data).html() + '" onclick="deleteRow(this.value)" class="btn btn-success btn-sm"  title="Delete">Delete</button></div>';
			   }
			}],
	});
});

//Edit Employee
var editEmployee = function(id){
	$('form#employeeForm h5').text('Edit Employee');
	$('form#employeeForm').attr('onsubmit','return addEmployee(event,'+id+')');
	$.ajax({
		  type: "GET",
		  url: "http://localhost:8086/employee/"+id,
			success: (function(data, status){
				data =(data);
			  $.each(data, function(key, value){
					$('form#employeeForm [name=' + key + ']').val(value);	
					});
			}),
	});
$("#viewForm").modal();
}

//delete Employee
var deleteRow = function(id){
	requesturl = "http://localhost:8086/employee/"+id,
	$.ajax({
		  type: "DELETE",
		  url: requesturl,
		  data: null,
		  success: function(data,status){
			  alert(data);
			  window.location.reload();
		  },
		  datatype : "application/json",
		  contentType: "application/json"
	});
}

//SEARCH

var SearchResult=function(enterNumber,opetions){
	var enterNumber = $('#enterNumber').val();
	var opetions = $('#opetions').val();
	console.log(enterNumber);
	console.log(opetions);
	var url= "http://localhost:8086/employee/search/"+enterNumber+"/"+opetions;
	salaryTable = $('#salaryTable').DataTable({
		  processing : true,
			destroy: true,
			paging: false,
			searching : false,
			info : false,
		ajax: {
				url: url,
				"type" : "GET",
				dataSrc: function (json) {
					return json;
				 },
				datatype : "application/json",
				contentType: "application/json"
		},
		columns : [ {
			data : "fullName",
			'title' : " Name"
		}, {
			data : "email",
			'title' : "Email"
		}, {
			data : "salary",
			'title' : "Salary"
		}],
	});
}
