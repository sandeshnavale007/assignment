package com.management.employee.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.management.employee.entity.Employee;

public interface EmployeeRepository extends CrudRepository<Employee, Long> {

	List<Employee> findBySalaryGreaterThan(String enterNumber);

	List<Employee> findBySalaryLessThan(String enterNumber);

	Employee findByEmail(String username);

}
