package com.management.employee.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.management.employee.entity.EmployeeExcel;

public interface EmployeeExcelRepository extends JpaRepository<EmployeeExcel, Integer> {

}
