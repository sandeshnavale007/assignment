package com.management.employee.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.management.employee.entity.UploadDocument;

public interface UploadDocumentRepository extends JpaRepository<UploadDocument, Integer> {

}
