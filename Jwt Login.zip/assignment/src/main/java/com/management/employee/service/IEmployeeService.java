package com.management.employee.service;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.util.List;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import com.management.employee.dto.APIResponse;
import com.management.employee.dto.EmployeeDto;
import com.management.employee.dto.Login;
import com.management.employee.dto.UploadDocumentDto;
import com.management.employee.dto.UserResponse;
import com.management.employee.entity.Employee;
import com.management.employee.entity.EmployeeExcelDto;
import com.management.employee.entity.UploadDocument;

public interface IEmployeeService {

	public APIResponse<String> save(EmployeeDto employeeDto);

	public List<EmployeeDto> findAll();

	public EmployeeDto findEmpById(long id);
	
	public APIResponse<String> delete(long id);

	public List<EmployeeDto> findByHighSalary();

	public List<EmployeeDto> findByLessSalary();

	public List<Employee> findBySalary(String enterNumber, String options);

	public UserResponse login(Login login) throws Exception;

	public String uploadDocument(MultipartFile file, UploadDocumentDto request);

	public List<UploadDocument> findAll1();

	public Resource getImage(String uploadedDocuments, String fileName) throws MalformedURLException, FileNotFoundException;

	public APIResponse<String> uploadExcel(MultipartFile file);

	public List<EmployeeExcelDto> findAllExcel();

}
