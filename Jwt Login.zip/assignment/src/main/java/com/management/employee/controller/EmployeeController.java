package com.management.employee.controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.management.employee.dto.APIResponse;
import com.management.employee.dto.ApiResponseError;
import com.management.employee.dto.EmployeeDto;
import com.management.employee.dto.Login;
import com.management.employee.dto.UploadDocumentDto;
import com.management.employee.dto.UserResponse;
import com.management.employee.entity.Employee;
import com.management.employee.entity.EmployeeExcelDto;
import com.management.employee.entity.UploadDocument;
import com.management.employee.service.IEmployeeService;

@RestController
@CrossOrigin(origins = "http://localhost:4300")
@RequestMapping("employee")
public class EmployeeController {
	@Autowired
	private IEmployeeService employeeService;

	@PostMapping("/login")
	public ResponseEntity login(@RequestBody Login login) {
		APIResponse<UserResponse> apiResponse = null;
		try {
			apiResponse = new APIResponse<>();
			UserResponse user = employeeService.login(login);
			apiResponse.setData(user);
			apiResponse.setCode(200);
		}catch (Exception e) {
			ApiResponseError error = new ApiResponseError(0, null);
			error.setMessage("Unauthorized");;
			error.setCode(401);
			return ResponseEntity.status(error.getCode()).body(error);
		}
		return ResponseEntity.status(200).body(apiResponse);
	}

	@PostMapping("/")
	public ResponseEntity<APIResponse<String>> save(@Valid @RequestBody EmployeeDto employeedto,@RequestHeader(value = "Authorization") String authToken) {
		System.out.println("---------"+authToken); 
		return ResponseEntity.ok(employeeService.save(employeedto));
	}

	@PutMapping("/")
	public ResponseEntity<APIResponse<String>>  update(@RequestBody EmployeeDto employeedto) {
		 return ResponseEntity.ok(employeeService.save(employeedto));
	}

	@GetMapping("/")
	public List<EmployeeDto> findAll() {
		return (List<EmployeeDto>) employeeService.findAll();
	}

	@GetMapping("/{id}")
	public EmployeeDto findById(@PathVariable("id") long id) {
		return employeeService.findEmpById(id);
	}

	@DeleteMapping("/{id}")
	public  APIResponse<String> delete(@PathVariable("id") long id) {
		return employeeService.delete(id);
	}

	@GetMapping("/high")
	public List<EmployeeDto> findByHighSalary() {
		return employeeService.findByHighSalary();
	}

	@GetMapping("/less")
	public List<EmployeeDto> findByLessSalary() {
		return employeeService.findByLessSalary();
	}

	@GetMapping("/search/{enterNumber}/{options}")
	public List<Employee> findBySalary(@PathVariable("enterNumber") String enterNumber,
			@PathVariable("options") String options) {
		return employeeService.findBySalary(enterNumber, options);
	}

	@PostMapping("/upload")
	public String upload(@RequestParam(value = "file") MultipartFile file,
			@RequestParam("strContent") String strContent) throws JsonMappingException, JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		UploadDocumentDto request = mapper.readValue(strContent, UploadDocumentDto.class);
		System.out.println("----------" + file);
		return employeeService.uploadDocument(file, request);
	}

	@GetMapping("/upload")
	public List<UploadDocument> finAll() {
		return employeeService.findAll1();
	}

	@GetMapping("/{uploadedDocuments}/{fileName}")
	public ResponseEntity<Resource> findPath(@PathVariable String uploadedDocuments, @PathVariable String fileName,
			HttpServletRequest request) throws MalformedURLException, FileNotFoundException {
		Resource resource = employeeService.getImage(uploadedDocuments, fileName);
		String contentType = null;
		try {
			contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
		} catch (IOException ex) {
		}
		if (Objects.isNull(contentType)) {
			contentType = "application/octet-stream";
		}
		return ResponseEntity.ok().contentType(MediaType.parseMediaType(contentType))
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
				.body(resource);
	}
	
	
	@PostMapping("/uploadExcel")
	public ResponseEntity<APIResponse<String>> uploadExcel(@RequestParam(value = "file") MultipartFile file,
			@RequestParam("strContent") String strContent) throws JsonMappingException, JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
//		EmployeeExcelDto request = mapper.readValue(strContent, EmployeeExcelDto.class);
		return ResponseEntity.ok( employeeService.uploadExcel(file));
	}
	@GetMapping("/excelData")
	public List<EmployeeExcelDto> finAllData() {
		return employeeService.findAllExcel();
	}
}
