package com.management.employee.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.management.employee.common.TokenManager;
import com.management.employee.dao.EmployeeExcelRepository;
import com.management.employee.dao.EmployeeRepository;
import com.management.employee.dao.EmployeeRepositoryImpl;
import com.management.employee.dao.SalaryRepository;
import com.management.employee.dao.UploadDocumentRepository;
import com.management.employee.dto.APIResponse;
import com.management.employee.dto.CustomException;
import com.management.employee.dto.EmployeeDto;
import com.management.employee.dto.Login;
import com.management.employee.dto.UploadDocumentDto;
import com.management.employee.dto.UserResponse;
import com.management.employee.entity.Employee;
import com.management.employee.entity.EmployeeExcel;
import com.management.employee.entity.EmployeeExcelDto;
import com.management.employee.entity.Salary;
import com.management.employee.entity.UploadDocument;

@Service
public class EmployeeService implements IEmployeeService {

	@Autowired
	private EmployeeRepository repository;
	
	@Autowired
	private SalaryRepository salaryRepository;
	
	@Autowired
	private EmployeeRepositoryImpl nRepo;
	
	@Autowired
	private UploadDocumentService uploadService;
	
	@Autowired
	private EmployeeExcelRepository repositoryExcelUpload;
	
	@Autowired
	private UploadDocumentRepository uploadDocumentRepository;
	
    private final String api_dir = "uploadedDocuments";
    
    private String baseUrl = "http://localhost:8087";
    
    @Autowired
    private Environment environment;
    
	@Override
	public UserResponse login(Login login) throws Exception {
		UserResponse response = new UserResponse();
		Employee logindetail= repository.findByEmail(login.getUsername());
		if(Objects.nonNull(logindetail)) {
			if(logindetail.getEmail().equals(login.getUsername()) && logindetail.getPassword().equals(login.getPassword())) {
				BeanUtils.copyProperties(logindetail, response);
				String token = TokenManager.issueToken(logindetail, 24);
				response.setToken(token);
			}else{
				 throw new CustomException("Login Failed !");
			}
		}else {
			 throw new CustomException("please try again !");
		}
        return response;
	}
	
	@Override
	public APIResponse<String> save(EmployeeDto employeeDto) {
		System.out.println("old");
		Employee employee = new Employee();
		Employee logindetail= repository.findByEmail(employeeDto.getEmail());
		if(Objects.nonNull(logindetail))
		{
		       return new APIResponse.APIResponseBuilder<>().setCode(HttpStatus.OK.value()).setSuccess(true).setData("User Alreaddy Exists").createAPIResponse();

		}
		if (employeeDto.getId() == 0) {
			//Add Employee
			BeanUtils.copyProperties(employeeDto, employee);
			repository.save(employee);
			Salary salary = new Salary();
			salary.setEmployeeId(employee.getId());
			salary.setSalary(employeeDto.getSalary());
			salaryRepository.save(salary);
		} else {
			//update Employee
			BeanUtils.copyProperties(employeeDto, employee);
			repository.save(employee);
			Salary salary = salaryRepository.findByEmployeeId(employeeDto.getId());
			salary.setSalary(employeeDto.getSalary());
			salaryRepository.save(salary);
		}
	       return new APIResponse.APIResponseBuilder<>().setCode(HttpStatus.OK.value()).setSuccess(true).setData("Form submitted successfully").createAPIResponse();
	}

	@Override
	public List<EmployeeDto> findAll() {
		List<Employee> employee = new ArrayList<Employee>();
		Salary salary = new Salary();
		employee = (List<Employee>) repository.findAll();
		List<EmployeeDto> employeeDto = new ArrayList<EmployeeDto>();
		for (Employee e : employee) {
			EmployeeDto dto = new EmployeeDto();
			salary = salaryRepository.findByEmployeeId(e.getId());
			BeanUtils.copyProperties(e, dto);
//			dto.setSalary(salary.getSalary());
			employeeDto.add(dto);
		}
		return employeeDto;
	}

	@Override
	public EmployeeDto findEmpById(long id) {
		Employee employee = repository.findById(id).get();
		EmployeeDto dto = new EmployeeDto();
		Salary salary = salaryRepository.findByEmployeeId(employee.getId());
		BeanUtils.copyProperties(employee, dto);
//		dto.setSalary(salary.getSalary());
		return dto;
	}

	@Override
	public APIResponse<String> delete(long id) {
		repository.delete(repository.findById(id).get());
		salaryRepository.delete(salaryRepository.findByEmployeeId(id));
	       return new APIResponse.APIResponseBuilder<>().setCode(HttpStatus.OK.value()).setSuccess(true).setData("Form submitted successfully").createAPIResponse();
	}

	@Override
	public List<EmployeeDto> findByHighSalary() {
		return nRepo.findByHighSalary();
	}

	@Override
	public List<EmployeeDto> findByLessSalary() {
		return nRepo.findByLessSalary();
	}

	@Override
	public List<Employee> findBySalary(String enterNumber, String options) {
		if (options.equalsIgnoreCase("GREATERTHAN")) {
			 List<Employee> employee = repository.findBySalaryGreaterThan(enterNumber);
			 return employee;
		} else if(options.equalsIgnoreCase("LESSTHAN")){
			 List<Employee> employee =  repository.findBySalaryLessThan(enterNumber);
			 return employee;
		}
		return null;
	}
	@Override
	public String uploadDocument(MultipartFile file, UploadDocumentDto uploadDto) {
		String mediaAccessUrl = null;
		String fileName = "";
		UploadDocument upload = new UploadDocument();
			if (Objects.nonNull(file)) {
				try {
					fileName = uploadService.storeFile(file);
				} catch (Exception e) {
					e.printStackTrace();
				}
				mediaAccessUrl =  fileName;
			}
			upload.setDocuments(api_dir + "/" + mediaAccessUrl);
			upload.setDocumentName(uploadDto.getDocumentName());
			uploadDocumentRepository.save(upload);
		return "Document Uploaded";
	}

	@Override
	public List<UploadDocument> findAll1() {
		List<UploadDocument> uploadDocuments = uploadDocumentRepository.findAll();
		List<UploadDocument> ar= new ArrayList<>();
		uploadDocuments.forEach(x -> {
			UploadDocument up = new UploadDocument();
//			 try {
//                 up.setDocuments(InetAddress.getLocalHost().getHostAddress() + ":" + environment.getProperty("local.server.port") + x.getDocuments());
//             } catch (UnknownHostException e) {
//                 e.printStackTrace();
				up.setId(x.getId());
				up.setDocumentName(x.getDocumentName());
             	up.setDocuments(baseUrl +"/employee/"+ x.getDocuments());
//             }
			ar.add(up);
		});
		uploadDocuments.addAll(ar);
		return ar;
	}
	
    @Override
    public Resource getImage(String uploadedDocuments, String fileName) throws MalformedURLException, FileNotFoundException {
        String home = System.getProperty("user.home");
        String fullPath = home + File.separator + "files" + File.separator + uploadedDocuments + File.separator + fileName;
        Path filePath = Paths.get(fullPath);
        Resource resource = new UrlResource(filePath.toUri());

        if (!resource.exists())
            throw new FileNotFoundException("File not found ");
        return resource;
    }

	@Override
	public APIResponse<String> uploadExcel(MultipartFile file) {
			uploadService.ExcelUpload(file);
	       return new APIResponse.APIResponseBuilder<>().setCode(HttpStatus.OK.value()).setSuccess(true).setData("Excel Uploaded successfully").createAPIResponse();
	}
	@Override
	public List<EmployeeExcelDto> findAllExcel() {
		List<EmployeeExcelDto> excelList = new ArrayList<EmployeeExcelDto>();
		List<EmployeeExcel> uploadDocuments = repositoryExcelUpload.findAll();
		uploadDocuments.stream().forEach(x -> {
	        DateFormat f = new SimpleDateFormat("dd-MM-yyyy");
			EmployeeExcelDto excel = new EmployeeExcelDto();
			BeanUtils.copyProperties(x, excel);
	        excel.setInsertDate(f.format(x.getInsertDate()));

			excelList.add(excel);
		});
		return excelList;
	}
}
