package com.management.employee.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.management.employee.dao.EmployeeExcelRepository;
import com.management.employee.dao.EmployeeRepository;
import com.management.employee.entity.Employee;
import com.management.employee.entity.EmployeeExcel;

import javassist.NotFoundException;

@Service
public class UploadDocumentService {
    private final String upload_dir = "files";
    private Path fileStorageLocation = null;
    private final String api_dir = "uploadedDocuments";


	@Autowired
	private EmployeeExcelRepository repository;
	
	
	public String storeFile(MultipartFile file) throws Exception {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMddhhmmss");
        String currdate = simpleDateFormat.format(new Date());
        String home = System.getProperty("user.home");
        String uploadpath = home + "/" + upload_dir + "/" + api_dir; // full path where file stored
        fileStorageLocation = Paths.get(uploadpath).toAbsolutePath().normalize();
        try {
            Files.createDirectories(this.fileStorageLocation);
        } catch (Exception ex) {

            ex.printStackTrace();
        }
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());
        
        try {
            String[] fnamearray = fileName.split("\\.");
            if (fnamearray.length > 1) {
                    fileName = file.getOriginalFilename();
            }
            Path targetLocation = this.fileStorageLocation.resolve(fileName);
            Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
            return fileName.trim();
        } catch (IOException ex) {
            ex.printStackTrace();
            throw new NotFoundException("Could not store file ");
        }
    }
	
	
	
	public String ExcelUpload(MultipartFile file) {
		try {
		      Workbook workbook = new XSSFWorkbook(file.getInputStream());

		      Sheet sheet = workbook.getSheetAt(0);
		      Iterator<Row> rows = sheet.iterator();

		      List<EmployeeExcel> tutorials = new ArrayList<EmployeeExcel>();

		      int rowNumber = 0;
		      while (rows.hasNext()) {
		        Row currentRow = rows.next();

		        // skip header
		        if (rowNumber == 0) {
		          rowNumber++;
		          continue;
		        }

		        Iterator<Cell> cellsInRow = currentRow.iterator();

		        EmployeeExcel tutorial = new EmployeeExcel();

		        int cellIdx = 0;
		        while (cellsInRow.hasNext()) {
		          Cell currentCell = cellsInRow.next();

		          switch (currentCell.getColumnIndex()) {

//		          case 0:
//		            double i = currentCell.getNumericCellValue();
//		            System.out.println(i);
//		            break;
//		            
		          case 0:
			            tutorial.setFullName(currentCell.getStringCellValue());
			            break;

		          case 1:
		            tutorial.setEmail(currentCell.getStringCellValue());
		            break;

		          case 2:
		            tutorial.setPassword(currentCell.getStringCellValue());
		            break;

		          case 3:
		            tutorial.setSalary(currentCell.getStringCellValue());
		            break;
		          case 4:
			            tutorial.setInsertDate(currentCell.getDateCellValue());
			            break;

		          default:
		            break;
		          }

		          cellIdx++;
		        }

		        tutorials.add(tutorial);
		      }
		      repository.saveAll(tutorials);
		      workbook.close();

		      return "sucess";
		    } catch (IOException e) {
		      throw new RuntimeException("fail to parse Excel file: " + e.getMessage());
		    }
		  }
	
}
