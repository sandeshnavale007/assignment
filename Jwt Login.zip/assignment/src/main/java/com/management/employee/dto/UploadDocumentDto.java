package com.management.employee.dto;

import org.springframework.web.multipart.MultipartFile;

public class UploadDocumentDto {
	
	private int id;
	private String documentName;
//	private MultipartFile documents;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
//	public MultipartFile getDocuments() {
//		return documents;
//	}
//	public void setDocuments(MultipartFile documents) {
//		this.documents = documents;
//	}

}
