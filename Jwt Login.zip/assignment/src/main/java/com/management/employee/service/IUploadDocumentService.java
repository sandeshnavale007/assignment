package com.management.employee.service;

public interface IUploadDocumentService {

}
